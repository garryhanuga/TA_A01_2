package apap.ta.service;
import apap.ta.model.RoleModel;

import java.util.List;

public interface RoleService {
    List<RoleModel> findAll();

}
