package apap.ta.service;

import apap.ta.model.MesinModel;

import java.util.List;

public interface MesinRestService {
    List<MesinModel> retrieveListMesin();
}
