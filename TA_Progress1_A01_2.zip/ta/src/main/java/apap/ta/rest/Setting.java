package apap.ta.rest;

public class Setting {
    final public static String requestUpdateItemUrl = "";
    final public static String itemUrl = "https://si-item.herokuapp.com/api/item";
    final public static String mesinUrl = "";

}