
function myFunction() {
  confirm("Klik OK untuk Submit");
}