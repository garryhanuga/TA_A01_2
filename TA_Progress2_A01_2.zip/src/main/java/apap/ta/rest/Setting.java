package apap.ta.rest;

public class Setting {
    final public static String requestUpdateItemUrl = "https://sifactoru-a01.herokuapp.com/api/v2/requestupdateitem";
    final public static String itemUrl = "https://si-item.herokuapp.com/api/item";
    final public static String mesinUrl = "";
    final public static String cabangUrl = "https://444ad093-5662-4985-9db6-c1f81c72c0d5.mock.pstmn.io/rest/listCabang";
    final public static String proposeItemUrl = "https://tk-apap-a01-1.herokuapp.com/api/item-factory";


}