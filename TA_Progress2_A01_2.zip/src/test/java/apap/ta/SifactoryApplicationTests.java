package apap.ta;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SifactoryApplicationTests {

	@Test
	void contextLoads() {
	}

}
